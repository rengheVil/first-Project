let users = [];
let cars = [];
let rentals = [];
const categories = ['Car'];

function loadData() {
    users = JSON.parse(localStorage.getItem('users')) || [];
    cars = JSON.parse(localStorage.getItem('cars')) || [];
    rentals = JSON.parse(localStorage.getItem('rentals')) || [];
}

function saveData() {
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('cars', JSON.stringify(cars));
    localStorage.setItem('rentals', JSON.stringify(rentals));
}

function login(username, password, role) {
    const user = users.find(u => u.username === username && u.password === password && u.role === role);
    if (user) {
        sessionStorage.setItem('currentUser', JSON.stringify(user));
        return true;
    }
    return false;
}

function register(username, password, nic, role) {
    if (users.some(u => u.username === username)) {
        return false;
    }
    const newUser = { username, password, nic, role };
    users.push(newUser);
    saveData();
    return true;
}

function logout() {
    sessionStorage.removeItem('currentUser');
}

function getCurrentUser() {
    return JSON.parse(sessionStorage.getItem('currentUser'));
}

function addCar(regNumber, brand, model, category, imageData) {
    const newCar = { regNumber, brand, model, category, imageData };
    cars.push(newCar);
    saveData();
    updateCarTable();
    updateAvailableCars();
}

function removeCar(index) {
    cars.splice(index, 1);
    saveData();
    updateCarTable();
    updateAvailableCars();
}

function rentCar(regNumber) {
    const currentUser = getCurrentUser();
    const rental = {
        regNumber,
        username: currentUser.username,
        rentDate: new Date().toISOString()
    };
    rentals.push(rental);
    saveData();
    updateAvailableCars();
    updateCustomerRentals();
}

function returnCar(index) {
    const rental = rentals[index];
    const returnDate = new Date().toISOString();
    const orderHistoryItem = { ...rental, returnDate };
    
    
    const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
    orderHistory.push(orderHistoryItem);
    localStorage.setItem('orderHistory', JSON.stringify(orderHistory));
    
    rentals.splice(index, 1);
    saveData();
    updateAvailableCars();
    updateCustomerRentals();
    updateOrderHistory();
}

function isCarRented(regNumber) {
    return rentals.some(rental => rental.regNumber === regNumber);
}

function updateUserInfo() {
    const userInfo = document.getElementById('userInfo');
    const currentUser = getCurrentUser();
    if (userInfo && currentUser) {
        userInfo.textContent = `Logged in as: ${currentUser.username} (${currentUser.role})`;
    }
}

function updateOrderHistory() {
    const orderHistoryTableBody = document.getElementById('orderHistoryTableBody');
    const orderHistory = JSON.parse(localStorage.getItem('orderHistory')) || [];
    const currentUser = getCurrentUser();

    if (orderHistoryTableBody) {
        orderHistoryTableBody.innerHTML = '';
        orderHistory.forEach((order) => {
            if (currentUser.role === 'manager' || order.username === currentUser.username) {
                const car = cars.find(mb => mb.regNumber === order.regNumber);
                if (car) {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${car.regNumber}</td>
                        <td>${car.brand}</td>
                        <td>${car.model}</td>
                        <td>${new Date(order.rentDate).toLocaleString()}</td>
                        <td>${new Date(order.returnDate).toLocaleString()}</td>
                    `;
                    orderHistoryTableBody.appendChild(row);
                }
            }
        });
    }
}

function updateCarTable() {
    const carTableBody = document.getElementById('carTableBody');
    if (carTableBody) {
        carTableBody.innerHTML = '';
        cars.forEach((car, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${car.regNumber}</td>
                <td>${car.brand}</td>
                <td>${car.model}</td>
                <td>${car.category}</td>
                <td><button class="btn btn-danger btn-sm" onclick="removeCar(${index})">Remove</button></td>
            `;
            carTableBody.appendChild(row);
        });
    }
}

function updateAvailableCars() {
    const availableCarTableBody = document.getElementById('availableCarTableBody');
    if (availableCarTableBody) {
        availableCarTableBody.innerHTML = '';
        cars.forEach((car) => {
            if (!isCarRented(car.regNumber)) {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${car.regNumber}</td>
                    <td>${car.brand}</td>
                    <td>${car.model}</td>
                    <td>${car.category}</td>
                    <td>
                        ${car.imageData ? `<img src="${car.imageData}" alt="${car.brand} ${car.model}" style="width: 100px; height: auto;">` : 'No image'}
                    </td>
                    <td><button class="btn btn-primary btn-sm" onclick="rentCar('${car.regNumber}')">Rent</button></td>
                `;
                availableCarTableBody.appendChild(row);
            }
        });
    }
}

function updateCustomerRentals() {
    const myRentalsTableBody = document.getElementById('myRentalsTableBody');
    const customerRentalsTableBody = document.getElementById('customerRentalsTableBody');
    const currentUser = getCurrentUser();

    if (myRentalsTableBody) {
        myRentalsTableBody.innerHTML = '';
        rentals.forEach((rental, index) => {
            if (rental.username === currentUser.username) {
                const car = cars.find(mb => mb.regNumber === rental.regNumber);
                if (car) {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${car.regNumber}</td>
                        <td>${car.brand}</td>
                        <td>${car.model}</td>
                        <td>${car.category}</td>
                        <td>${new Date(rental.rentDate).toLocaleString()}</td>
                        <td><button class="btn btn-danger btn-sm" onclick="returnCar(${index})">Return</button></td>
                    `;
                    myRentalsTableBody.appendChild(row);
                }
            }
        });
    }

    if (customerRentalsTableBody) {
        customerRentalsTableBody.innerHTML = '';
        rentals.forEach((rental) => {
            const car = cars.find(mb => mb.regNumber === rental.regNumber);
            if (car) {
                const row = document.createElement('tr');
                const rentDate = new Date(rental.rentDate);
                const currentDate = new Date();
                const minutesDiff = (currentDate - rentDate) / (1000 * 60);
                
                let statusClass = minutesDiff > 1 ? 'table-danger' : 'table-success';
                let statusText = minutesDiff > 1 ? 'Overdue' : 'Active';

                row.className = statusClass;
                row.innerHTML = `
                    <td>${rental.username}</td>
                    <td>${car.regNumber}</td>
                    <td>${car.brand}</td>
                    <td>${car.model}</td>
                    <td>${new Date(rental.rentDate).toLocaleString()}</td>
                    <td>${statusText}</td>
                `;
                customerRentalsTableBody.appendChild(row);
            }
        });
    }
}
function checkOverdueRentals() {
    const currentDate = new Date();
    const overdueRentals = rentals.filter(rental => {
        const rentDate = new Date(rental.rentDate);
        const minutesDiff = (currentDate - rentDate) / (1000 * 60);
        return minutesDiff > 1;
    });

    if (overdueRentals.length > 0) {
        alert(`There are ${overdueRentals.length} overdue rentals!`);
    }
}


document.addEventListener('DOMContentLoaded', function() {
    loadData();

    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');
    const addCarForm = document.getElementById('addCarForm');
    const logoutBtn = document.getElementById('logoutBtn');

    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('loginUsername').value;
            const password = document.getElementById('loginPassword').value;
            const role = document.getElementById('loginRole').value;
            if (login(username, password, role)) {
                location.href = role === 'manager' ? 'manager.html' : 'customer.html';
            } else {
                alert('Invalid Username or Password');
            }
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('registerUsername').value;
            const password = document.getElementById('registerPassword').value;
            const nic = document.getElementById('registerNIC').value;
            const role = document.getElementById('registerRole').value;
            if (register(username, password, nic, role)) {
                alert('Registration successful. Please login.');
                registerForm.reset();
            } else {
                alert('Username already exists');
            }
        });
    }

    if (addCarForm) {
        const categorySelect = document.getElementById('category');
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categorySelect.appendChild(option);
        });

        addCarForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const regNumber = document.getElementById('regNumber').value;
            const brand = document.getElementById('brand').value;
            const model = document.getElementById('model').value;
            const category = document.getElementById('category').value;
            const imageFile = document.getElementById('carImage').files[0];
    
            if (imageFile) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    addCar(regNumber, brand, model, category, event.target.result);
                };
                reader.readAsDataURL(imageFile);
            } else {
                addCar(regNumber, brand, model, category, null);
            }
            addCarForm.reset();
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            logout();
            location.href = 'index.html';
        });
    }

    updateUserInfo();
    updateCarTable();
    updateAvailableCars();
    updateCustomerRentals();
    checkOverdueRentals();
    updateOrderHistory();
});

const addEventOnElem = function (elem, type, callback) {
    if (elem.length > 1) {
      for (let i = 0; i < elem.length; i++) {
        elem[i].addEventListener(type, callback);
      }
    } else {
      elem.addEventListener(type, callback);
    }
  }
  
  
  const navbar = document.querySelector("[data-navbar]");
  const navbarLinks = document.querySelectorAll("[data-nav-link]");
  const navTogglers = document.querySelectorAll("[data-nav-toggler]");
  const overlay = document.querySelector("[data-overlay]");
  
  const toggleNavbar = function () {
    navbar.classList.toggle("active");
    overlay.classList.toggle("active");
    document.body.classList.toggle("active");
  }
  
  addEventOnElem(navTogglers, "click", toggleNavbar);
  
  const closeNavbar = function () {
    navbar.classList.remove("active");
    overlay.classList.remove("active");
    document.body.classList.remove("active");
  }
  
  addEventOnElem(navbarLinks, "click", closeNavbar);
  
  
  const header = document.querySelector("[data-header]");
  const backTopBtn = document.querySelector("[data-back-top-btn]");
  
  const showElemOnScroll = function () {
    if (window.scrollY > 100) {
      header.classList.add("active");
      backTopBtn.classList.add("active");
    } else {
      header.classList.remove("active");
      backTopBtn.classList.remove("active");
    }
  }
  
  addEventOnElem(window, "scroll", showElemOnScroll);
  
  
  const filterBtns = document.querySelectorAll("[data-filter-btn]");
  const filterBox = document.querySelector("[data-filter]");
  
  let lastClickedFilterBtn = filterBtns[0];
  
  const filter = function () {
    lastClickedFilterBtn.classList.remove("active");
    this.classList.add("active");
    lastClickedFilterBtn = this;
  
    filterBox.setAttribute("data-filter", this.dataset.filterBtn)
  }
  
  addEventOnElem(filterBtns, "click", filter);